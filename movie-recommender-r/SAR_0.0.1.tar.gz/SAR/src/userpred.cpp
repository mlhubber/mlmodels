#include <Rcpp.h>

struct User_rec
{
    int item;      // recommended item: use item index no. rather than text label, to avoid copying chars around
    double score;  // recommended score
};


static bool User_rec_greater(const User_rec& a, const User_rec& b)
{
    return a.score > b.score;
}


// [[Rcpp::export]]
Rcpp::List user_predict_ranking(Rcpp::NumericMatrix aff,
                                Rcpp::NumericMatrix recs,
                                const int n_recs,
                                const bool include_seed_items)
{
    const int n_users = aff.nrow();
    const int n_items = aff.ncol();

    Rcpp::NumericMatrix rec_scores(n_users, n_recs);
    Rcpp::NumericMatrix rec_items(n_users, n_recs);

    for (int i = 0; i < n_users; i++)
    {
        std::vector<User_rec> user_rec;
        user_rec.reserve(n_items);

        if (!include_seed_items)
        {
            // only keep recs that correspond to zero item affinities
            // TODO: handle case where not enough items left to recommend
            for (int j = 0; j < n_items; j++)
            {
                if (aff(i, j) == 0)
                {
                    User_rec rec_j;
                    rec_j.item = j;
                    rec_j.score = recs(j, i);

                    user_rec.push_back(rec_j);
                }
            }
        }
        else
        {
            for (int j = 0; j < n_items; j++)
            {
                user_rec[j].item = j;
                user_rec[j].score = recs(j, i);
            }
        }

        std::sort(user_rec.begin(), user_rec.end(), User_rec_greater);

        for (int j = 0; j < n_recs; j++)
        {
            rec_items(i, j) = user_rec[j].item + 1;  // convert to 1-based indexing for R
            rec_scores(i, j) = user_rec[j].score;
        }
    }

    return Rcpp::List::create(rec_scores, rec_items);
}
