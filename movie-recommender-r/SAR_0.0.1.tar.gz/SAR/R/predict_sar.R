#' @importMethodsFrom Matrix tcrossprod
#' @importClassesFrom Matrix dsCMatrix dgCMatrix
NULL


#' @export
user_predict <- function(object, userdata=NULL, n=5, include_seed_items=FALSE, reftime=Sys.time())
{
    user_col <- object$col_ids["user"]
    item_col <- object$col_ids["item"]
    time_col <- object$col_ids["time"]
    event_col <- object$col_ids["event"]
    weight_col <- object$col_ids["weight"]

    if(is.null(userdata))
        stop("Must provide new transaction events or users")

    if(is.data.frame(userdata))
    {
        user <- as.character(userdata[[user_col]])
        item <- userdata[[item_col]]
        time <- userdata[[time_col]]
        event <- userdata[[event_col]]
        weight <- userdata[[weight_col]]
    }
    else
    {
        user <- as.character(userdata)
        item <- time <- event <- weight <- NULL
    }

    t0 <- if(!missing(reftime))
        max(object$time, time, reftime)
    else max(object$time, time)  # if time not supplied, reduces to max(object$time)

    # if userids supplied, compute affinity matrix from training data for these users
    trn_aff <- if(length(user) > 0)
    {
        keep <- which(object$user %in% unique(user))

        wt <- calc_wt(object$event[keep], object$weight[keep], object$allowed_events)
        make_affinity(object$user[keep], object$item[keep], object$time[keep], wt, t0,
                      object$half_life, object$allowed_items)
    }
    else 0

    # if new transaction events supplied, compute affinity matrix from these events
    new_aff <- if(length(item) > 0)
    {
        item <- factor(item, levels=levels(object$item))
        wt <- calc_wt(event, weight, object$allowed_events)
        make_affinity(user, item, time, wt, t0, object$half_life, object$allowed_items)
    }
    else 0

    aff <- new_aff + trn_aff
    recs <- user_predict_ranking(as.matrix(aff), as.matrix(tcrossprod(object$sim_mat, aff)), n, include_seed_items)

    recs[[2]][] <- rownames(object$sim_mat)[recs[[2]]]
    colnames(recs[[1]]) <- paste0("score", seq_len(n))
    colnames(recs[[2]]) <- paste0("rec", seq_len(n))

    if(length(user) < 1)
        cbind.data.frame(recs[[2]], recs[[1]], stringsAsFactors=FALSE)
    else cbind.data.frame(user=sort(unique(user)), recs[[2]], recs[[1]], stringsAsFactors=FALSE)
}


#' @export
item_predict <- function(object, items, n=5)
{
    if(is.data.frame(items))
        items <- as.character(items$items)
    else items <- as.character(items)
    item_sim <- object$sim_mat[items,, drop=FALSE]

    ord <- apply(item_sim, 1, function(x)
    {
        order(x, decreasing=TRUE)[seq_len(n) + 1] # assuming largest elem will be on the diagonal
    })

    recs <- matrix(rownames(object$sim_mat)[ord], ncol=n, byrow=TRUE)

    scores <- t(sapply(seq_len(ncol(ord)), function(x)
    {
        item_sim[x, ord[, x]]
    }))

    recs <- cbind.data.frame(recs, scores, stringsAsFactors=FALSE)
    names(recs) <- c(paste0("rec", seq_len(n)), paste0("score", seq_len(n)))
    cbind(item=items, recs, stringsAsFactors=FALSE)
}
