#' @importFrom R6 R6Class
NULL

#' @export az_sar
#' @exportClass az_sar
az_sar <- R6Class("az_sar", public=list(
    initialize=function(service, admin_key, rec_key, instrument_key=NULL)
    {
        private$service <- service
        private$admin_key <- admin_key
        private$rec_key <- rec_key
        private$instr_key <- instrument_key

        self$list_models()
        self$get_default_model()
        invisible(NULL)
    },

    list_models=function(refresh=TRUE)
    {
        if(refresh)
        {
            result <- httr::GET(private$base_url(),
                                httr::add_headers(c("x-api-key"=private$admin_key,
                                                    "Content-Type"="application/json")))
            status <- httr::status_code(result)
            if(status >= 300)
                stop(status, ", unable to retrieve model list", call.=FALSE)
            content <- httr::content(result)

            # sync the model list with Azure
            private$models <- dplyr::bind_rows(content)
        }

        private$models
    },

    fit_model=function(description, container, usage_data, catalog_data=NULL, eval_data=NULL,
                       support_threshold=NULL, cooccurrence=NULL, similarity=NULL,
                       cold_items=NULL, cold_to_cold=NULL, user_affinity=NULL, backfill=NULL, include_seed_items=NULL,
                       half_life=NULL, user_to_items=NULL)
    {
        if(nrow(private$models) > 0 && description %in% private$models$description)
            stop("Model already exists with description '", description, "'", call.=FALSE)
        fit_args <- list(
            description=description,
            blobContainerName=container,
            usageRelativePath=usage_data,
            catalogFileRelativePath=catalog_data,
            evaluationUsageRelativePath=eval_data,
            supportThreshold=support_threshold,
            cooccurrenceUnit=cooccurrence,
            similarityFunction=similarity,
            enableColdItemPlacement=cold_items,
            enableColdToColdRecommendations=cold_to_cold,
            enableUserAffinity=user_affinity,
            enableBackfilling=backfill,
            allowSeedItemsInRecommendations=include_seed_items,
            decayPeriodInDays=half_life,
            enableUserToItemRecommendations=user_to_items
        )

        fit_args <- jsonlite::toJSON(lapply(fit_args[!sapply(fit_args, is.null)], jsonlite::unbox))

        result <- httr::POST(private$base_url(),
                             body=fit_args,
                             httr::add_headers(c("x-api-key"=private$admin_key,
                                                 "Content-Type"="application/json")))
        status <- httr::status_code(result)
        if(status >= 300)
            stop(status, ", problem creating model", call.=FALSE)

        content <- httr::content(result)

        # sync the model list with Azure
        private$add_model(content)

        class(content) <- "az_sar_model"
        content
    },

    show_model=function(description=NULL, id=NULL, refresh=TRUE)
    {
        if(refresh)
        {
            result <- httr::GET(private$model_url(description, id),
                                httr::add_headers(c("x-api-key"=private$admin_key)))

            status <- httr::status_code(result)
            if(status >= 300)
                stop(status, ", unable to retrieve model info", call.=FALSE)

            content <- httr::content(result)

            # sync the model list with Azure
            private$add_model(content)

            class(content) <- "az_sar_model"
            return(content)
        }

        id <- private$get_model_id(description, id)
        private$models[private$models$id == id,]
    },

    delete_model=function(description=NULL, id=NULL)
    {
        result <- httr::DELETE(private$model_url(description, id),
                               httr::add_headers(c("x-api-key"=private$admin_key)))

        status <- httr::status_code(result)
        if(status >= 300)
            stop(status, ", unable to delete model", call.=FALSE)

        if(length(private$default) > 0 && private$default == private$get_model_id(description, id))
            private$default <- character(0)

        # sync the model list with Azure
        id <- private$get_model_id(description, id)
        private$models <- private$models[-which(private$models$id == id),]
    },

    user_predict=function(description=NULL, id=NULL, userdata=NULL, n=NULL, raw_output=FALSE)
    {
        # assume userdata in fixed format
        if(is.data.frame(userdata))
        {
            users <- as.character(userdata$user)
            user_col <- which(names(userdata) == "user")
        }
        else users <- as.character(userdata)

        userid_provided <- length(users) > 0
        if(!userid_provided && !is.data.frame(userdata))
            stop("Must provide user IDs or transaction events to get recommendations for")

        url <- paste0(private$model_url(description, id), "/recommend?")

        users <- unique(users)
        n_users <- max(1, length(users))
        result <- vector("list", n_users)
        for(i in seq_len(n_users))
        {
            if(userid_provided)
                qry <- list(userId=users[i])
            else qry <- list()

            if(!is.null(n))
                qry <- c(qry, "recommendationCount"=n)

            if(length(qry) > 0)
                qry <- paste0(names(qry), "=", qry, collapse="&")
            else qry <- ""

            # wrangle any provided dataset into format the API can accept
            if(is.data.frame(userdata) && "item" %in% names(userdata))
            {
                if(userid_provided)
                    data_i <- userdata[userdata$user == users[i], - user_col, drop=FALSE]
                else data_i <- userdata

                # rename to match API conventions
                names(data_i)[names(data_i) == "item"] <- "itemId"
                names(data_i)[names(data_i) == "time"] <- "timestamp"
                names(data_i)[names(data_i) == "event"] <- "eventType"
                data_i <- jsonlite::toJSON(data_i)
            }
            else data_i <- NULL

            result_i <- httr::POST(paste0(url, qry),
                                   body=data_i,
                                   httr::add_headers(c("x-api-key"=private$rec_key,
                                                       "Content-Type"="application/json")))

            status <- httr::status_code(result_i)
            if(status >= 300)
                stop(status, ", unable to get personalised recommendations", call.=FALSE)

            result[[i]] <- httr::content(result_i)
        }
        if(raw_output)
            return(result)

        result <- dplyr::bind_rows(lapply(result, dplyr::bind_cols))
        names(result) <- paste0(c("rec", "score"), rep(seq_len(n), each=2))

        # reorder columns to match standalone predict
        perm <- c(matrix(seq_len(n * 2), ncol=2, byrow=TRUE))
        result <- result[perm]

        if(userid_provided)
            result <- dplyr::bind_cols(user=users, result)
        as.data.frame(result)
    },

    item_predict=function(description=NULL, id=NULL, item=NULL, n=NULL, raw_output=FALSE)
    {
        if(is.null(item))
            stop("Must provide item IDs to get recommendations for")
        if(is.data.frame(item))
            item <- item$item

        url <- paste0(private$model_url(description, id), "/recommend?")

        item <- unique(item)
        n_items <- length(item)
        result <- vector("list", n_items)
        for(i in seq_len(n_items))
        {
            url_i <- paste0(url, "itemId=", item[i])
            if(!is.null(n))
                url_i <- paste0(url_i, "&recommendationCount=", n)

            result_i <- httr::GET(url_i,
                                  httr::add_headers(c("x-api-key"=private$rec_key)))

            status <- httr::status_code(result_i)
            if(status >= 300)
                stop(status, ", unable to get item-to-item recommendations", call.=FALSE)

            result[[i]] <- httr::content(result_i)
        }
        if(raw_output)
            return(result)

        result <- dplyr::bind_rows(lapply(result, dplyr::bind_cols))
        result <- dplyr::bind_cols(item=item, result)
        names(result) <- c("item", paste0(c("rec", "score"), rep(seq_len(n), each=2)))

        # reorder columns to match standalone predict
        perm <- c(matrix(seq_len(n * 2), ncol=2, byrow=TRUE)) + 1
        as.data.frame(result[c(1, perm)])
    },

    get_default_model=function(refresh=TRUE)
    {
        if(refresh)
        {
            result <- httr::GET(paste0(private$base_url(), "/default"),
                                httr::add_headers(c("x-api-key"=private$admin_key)))

            status <- httr::status_code(result)
            if(status == 404) # no default model
                return(NULL)

            if(status >= 300)
                stop(status, ", unable to get default model", call.=FALSE)

            content <- httr::content(result)

            # sync default model with Azure
            private$default <- content$id

            class(content) <- "az_sar_model"
            return(content)
        }

        def <- private$default
        if(length(def) < 1)
        {
            message("No default model set")
            return(NULL)
        }
        self$show_model(id=def)
    },

    set_default_model=function(description=NULL, id=NULL)
    {
        id <- private$get_model_id(description, id)

        url <- paste0(private$base_url(), "/default?modelId=", id)
        result <- httr::PUT(url,
                            httr::add_headers(c("x-api-key"=private$admin_key)))

        status <- httr::status_code(result)
        if(status >= 300)
            stop(status, ", unable to set default model", call.=FALSE)

        private$default <- id
        invisible(NULL)
    },

    print=function(...)
    {
        cat("SAR Azure App Service object\n")
        cat("Service name:", private$service, "\n")
        cat("URL:", paste0("https://", private$service, ".azurewebsites.net\n"))
        cat("Number of models:", nrow(private$models), "\n")

        mods <- as.data.frame(private$models) # strip tbl_df class for printing
        if(nrow(mods) > 0)
        {
            mods$default <- " "
            mods$default[mods$id == private$default] <- "*   "
            cat("\nModel table:\n")
            print(as.data.frame(mods), ...)
        }

        invisible(self)
    },

    swagger_url=function()
    {
        sprintf("https://%s.azurewebsites.net/swagger", private$service)
    },

    service_url=function()
    {
        sprintf("https://%s.azurewebsites.net/api/models", private$service)
    }),


    ###
    ### private members ###########################################################################
    private=list(
        service=character(),
        admin_key=character(),
        rec_key=character(),
        instr_key=character(),
        models=dplyr::data_frame(),
        default=character(),

        base_url=function()
        {
            paste0("https://", private$service, ".azurewebsites.net/api/models")
        },

        model_url=function(description, id)
        {
            id <- private$get_model_id(description, id)
            paste0(private$base_url(), "/", id)
        },

        add_model=function(model_info)
        {
            model <- dplyr::bind_rows(model_info[c("id", "description", "creationTime", "modelStatus")])

            if(nrow(private$models) > 0)
            {
                cur_idx <- match(model$id, private$models$id)
                if(is.na(cur_idx))
                    private$models <- dplyr::bind_rows(private$models, model)
                else private$models[cur_idx,] <- model
            }
            else private$models <- model

            invisible(NULL)
        },

        get_model_id=function(description=NULL, id=NULL)
        {
            no_desc <- is.null(description)
            no_id <- is.null(id)
            if(no_desc && no_id)
            {
                # return default model on null input
                if(length(private$default) == 0)
                    stop("Must provide either model description string or ID", call.=FALSE)
                else return(private$default)
            }
            else if(!no_desc && !no_id)
                stop("Either provide model description string or ID, not both", call.=FALSE)
            else if(no_desc && !(id %in% private$models$id))
                stop("Model ID '", id, "' not found", call.=FALSE)
            else if(no_id && !(description %in% private$models$description))
                stop("Model '", description, "' not found", call.=FALSE)

            if(no_id)
                id <- private$models$id[private$models$description == description]
            if(length(id) > 1)
                stop("More than one model with given description", call.=FALSE)

            id
        }
    )
)


#' @export
print.az_sar_model <- function(x, ...)
{
    cat("SAR model from Azure App Service\n")
    cat("Name:", x$description, "\n")
    cat("Id:", x$id, "\n")
    cat("Creation time:", x$creationTime, "\n")
    cat("Status:", x$modelStatus, "\n")

    parms <- x$parameters
    class(parms) <- "simple.list"
    cat("\nModel training parameters:\n")
    print(parms, ...)

    if(!is.null(x$statistics))
    {
        stats <- x$statistics
        stats <- list("Training duration"=stats$trainingDuration,
                      "Total duration"=stats$totalDuration,
                      "Included events"=stats$usageEventsParsing$successfulLinesCount,
                      "Total events"=stats$usageEventsParsingtotalLinesCount,
                      "Item count"=stats$numberOfUsageItems,
                      "User count"=stats$numberOfUsers
        )
        class(stats) <- "simple.list"
        cat("\nTraining statistics:\n")
        print(stats)

        ev <- x$statistics$evaluation
        if(!is.null(ev))
        {
            evalstats <- list("Evaluation duration"=ev$duration,
                              "Total evaluation events"=ev$usageEventsParsing$totalLinesCount,
                              "Included evaluation events"=ev$usageEventsParsing$successfulLinesCount)
            class(evalstats) <- "simple.list"
            cat("\nEvaluation statistics:\n")
            print(evalstats)

            divstats <- list("Total items recommended"=ev$metrics$diversityMetrics$totalItemsRecommended,
                             "Unique items recommended"=ev$metrics$diversityMetrics$uniqueItemsRecommended,
                             "Unique items in training set"=ev$metrics$diversityMetrics$uniqueItemsInTrainSet)
            class(divstats) <- "simple.list"
            cat("\nDiversity metrics:\n")
            print(divstats)
            cat("\n")
            div <- as.data.frame(dplyr::bind_rows(ev$metrics$diversityMetrics$percentileBuckets))
            print(div)

            cat("\nPrecision metrics:\n")
            prec <- as.data.frame(dplyr::bind_rows(ev$metrics$precisionMetrics))
            print(prec)
        }
    }
    invisible(x)
}

