#' @useDynLib SAR, .registration=TRUE
#' @importFrom Rcpp sourceCpp
NULL

#' @export
sar <- function(...)
{
    UseMethod("sar")
}


#' @export
sar.data.frame <- function(x, user="user", item="item", time="time", event="event", weight="weight", ...)
{
    model <- sar.default(user=x[[user]], item=x[[item]], time=x[[time]], event=x[[event]], weight=x[[weight]], ...)
    model$col_ids <- c(user=user, item=item, time=time, event=event, weight=weight)
    class(model) <- c("sar.data.frame", class(model))
    model
}


#' @export
sar.default <- function(user, item, time, event=NULL, weight=NULL, support_threshold=1, allowed_items=NULL,
                        allowed_events=c(Click=1, RecommendationClick=2, AddShopCart=3, RemoveShopCart=-1, Purchase=4),
                        by_user=TRUE, similarity=c("jaccard", "lift", "count"), half_life=30,
                        feature_data=NULL, feature_formula=item ~ ., feature_model="lm", ...)
{
    if(missing(user) || is.null(user))
        stop("must supply column of user IDs")
    if(missing(item) || is.null(item))
        stop("must supply column of item IDs")
    if(missing(time) || is.null(time))
        stop("must supply column of event timestamps")

    similarity <- match.arg(similarity)

    wt <- calc_wt(event, weight, allowed_events)
    item <- if(is.null(allowed_items))
        as.factor(item)
    else factor(item, levels=sort(allowed_items))

    sim_mat <- make_similarity(user, item, time, allowed_items, support_threshold, by_user, similarity,
                               feature_data, feature_formula, feature_model, ...)
    #aff_mat <- make_affinity(user, item, time, wt, allowed_items, half_life)

    out <- list(sim_mat=sim_mat,
                user=as.character(user), item=item, time=time, event=event, weight=weight, # save the data
                allowed_items=unique(allowed_items), allowed_events=allowed_events,
                by_user=by_user, support_threshold=support_threshold,
                half_life=half_life, similarity=similarity)
    class(out) <- "sar"
    out
}


make_similarity <- function(user, item, time, allowed_items=NULL, support_threshold, by_user, similarity,
                            feature_data, feature_formula, feature_model, ...)
{
    dat <- dplyr::data_frame(user, item, time)
    
    grps <- if(by_user)
        dplyr::quo(user)
    else c(dplyr::quo(user), dplyr::quo(time))

    # call out to C++ to compute actual matrix: 2 order of magnitude speedup
    sim_matrix <- make_similarity_matrix(nlevels(dat$item),
                                         attr(dplyr::group_by(dat, !!!grps), "indices"),
                                         dat$item,
                                         support_threshold)

    occs <- diag(sim_matrix)
    warm <- occs >= support_threshold

    ### NOTE ###
    ### underlying C++ rescaling code will modify matrix elements in-place, to avoid making duplicate copies
    if(similarity == "lift")
        rescale_to_lift(sim_matrix, occs)
    else if(similarity == "jaccard")
        rescale_to_jaccard(sim_matrix, occs)

    # convert to (M)atrix to avoid warts when interacting with affinity matrix
    sim_matrix <- as(sim_matrix, "sparseMatrix")
    dimnames(sim_matrix) <- list(levels(dat$item), levels(dat$item))

    # fit regression model for cold items using item features, if required
    if(!all(warm) && !is.null(feature_data))
    {
        message("Fitting regression model to obtain similarities for cold items")
        items <- colnames(sim_matrix)
        model <- fit_feature_model(sim_matrix[warm, warm], feature_formula, feature_data, feature_model, items[warm], ...)

        cold_mf <- feature_model_frame(items[!warm], items, feature_formula, feature_data)

        # augment/replace cold items in similarity matrix
        cold_pred <- predict(model, cold_mf)

        cold_indices <- as.matrix(expand.grid(items[!warm], items))
        sim_matrix[cold_indices] <- cold_pred # fill in cold rows
        sim_matrix[cold_indices[, 2:1]] <- cold_pred # fill in cold columns

        attr(sim_matrix, "cold_indices") <- cold_indices
        attr(sim_matrix, "cold_pred") <- cold_pred
    }

    sim_matrix
}


# construct a model frame for the feature regression model: used for training and prediction
feature_model_frame <- function(item1, item2, feature_formula, feature_data)
{
    # extract item column name from LHS
    if(length(feature_formula) == 3)
    {
        item <- as.character(z[[2]])
        feature_formula <- feature_formula[[3]]
    }
    else
    {
        item <- "item"
        feature_formula <- feature_formula[[2]]
    }

    vars <- if(any(all.vars(feature_formula) == "."))
        all.vars(feature_data)
    else all.vars(feature_formula)
    vars <- setdiff(vars, item)

    mf <- expand.grid(item1=item1, item2=item2)
    vars <- lapply(feature_data[vars], function(x)
    {
        x1 <- x[match(mf$item1, feature_data[[item]])]
        x2 <- x[match(mf$item2, feature_data[[item]])]
        x1 == x2
    })
    dplyr::as_data_frame(vars, validate=FALSE)
}


# fit the regression model for predicting similarities for cold items, using feature data
fit_feature_model <- function(y, feature_formula, feature_data, feature_model, warm_items, ...)
{
    mf <- dplyr::bind_cols(y=as.numeric(y),
                           feature_model_frame(warm_items, warm_items, feature_formula, feature_data))

    feature_formula <- update(feature_formula, y ~ .)
    if(!is.function(feature_model))
        feature_model <- getFunction(feature_model)
    feature_model(feature_formula, mf, ...)
}


make_affinity <- function(user, item, time, wt, t0=max(time), half_life, allowed_items=NULL)
{
    # handle POSIXct datetimes; assume data is in days otherwise
    if(inherits(time, "POSIXct"))
        half_life <- half_life * 24 * 3600
    else if(!inherits(time, c("Date", "numeric")))
        stop("time variable must be numeric, POSIXct or Date")

    time <- as.numeric(time)
    t0 <- as.numeric(t0)
    if(length(wt) == 0)
        wt <- rep(1, length(time))
    if(half_life > 0)
        wt <- wt * 2 ^ ((time - t0) / half_life)

    # use sparse=TRUE to work around dimension problems with user, item large
    if(length(unique(user)) > 1)
        return(xtabs(wt ~ user + item, sparse=TRUE))
    else
    {
        out <- xtabs(wt ~ item)
        matrix(out, 1, dimnames=list(NULL, dimnames(out)[[1]]))
    }
}


#' @export
print.sar <- function(x, ...)
{
    cat("SAR model\n")
    cat("Support threshold:", x$support_threshold, "\n")
    cat("Co-occurrence unit:", if(x$by_user) "user\n" else "user/time\n")
    cat("Similarity function:", x$similarity, "\n")
    cat("Decay period in days:", x$half_life, "\n")
    cat("Item count:", nrow(x$sim_mat), "\n")
    cat("User count:", nrow(x$aff_mat), "\n")
    if(!is.null(x$col_ids))
    {
        cat("Column names:\n")
        print(x$col_ids)
    }
    invisible(x)
}


calc_wt <- function(event=NULL, weight=NULL,
                    allowed_events=c(Click=1, RecommendationClick=2, AddShopCart=3, RemoveShopCart=-1, Purchase=4))
{
    if(is.null(event) && is.null(weight))
        numeric(0)
    else if(!is.null(weight))
        weight
    else
    {
        stopifnot(all(event %in% names(allowed_events)))
        allowed_events[event]
    }
}


